from datetime import timedelta
from json import dumps

import airflow
from airflow import DAG
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from osdu_airflow.backward_compatibility.default_args import update_default_args
from osdu_airflow.operators.update_status import UpdateStatusOperator

# default args for airflow
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': airflow.utils.dates.days_ago(0),
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

default_args = update_default_args(default_args)

# Get values from dag run configuration
record_id = "{{ dag_run.conf['execution_context']['id'] }}"
authorization = "{{ dag_run.conf['authToken'] }}"
dataPartitionId = "{{ dag_run.conf['execution_context']['dataPartitionId'] }}"
run_id = "{{ dag_run.conf['run_id'] }}"
data_service_to_use = "{{ dag_run.conf['execution_context'].get('data_service_to_use', 'file') }}"
steps = ["LOAD_FROM_CSV", "TYPE_COERCION", "ID", "ACL", "LEGAL", "KIND", "META", "TAGS", "UNIT", "CRS", "RELATIONSHIP", "STORE_TO_OSDU"]
user_id = "{{ dag_run.conf['execution_context'].get('userId') }}"

# Constants
DAG_NAME = "csv-parser"
DOCKER_IMAGE = "{{ var.value.dag_image_acr }}/csv-parser:{{ var.value.csv_parser_image_tag }}"
NAMESPACE = "airflow"
CSV_PARSER = "csv-parser"

# Values to pass to csv parser
params = {
    "id": record_id,
    "authorization": authorization,
    "dataPartitionId": dataPartitionId,
    "steps": steps,
    "dataServiceName": "{{ dag_run.conf['execution_context'].get('data_service_to_use', 'file') }}",
    "userId":user_id
}

# Get environment variables
# TODO: put env vars here from application.properties
env_vars = {
    "storage_service_endpoint": "http://storage.osdu-core.svc.cluster.local/api/storage/v2",
    "schema_service_endpoint": "http://schema.osdu-core.svc.cluster.local/api/schema-service/v1",
    "search_service_endpoint": "http://search.osdu-core.svc.cluster.local/api/search/v2",
    "partition_service_endpoint": "http://partition.osdu-core.svc.cluster.local/api/partition/v1",
    "unit_service_endpoint": "http://unit.osdu-core.svc.cluster.local/api/unit/v2/unit/symbol",
    "file_service_endpoint": "http://file.osdu-core.svc.cluster.local/api/file/v2",
    "KEYVAULT_URI": "__KEYVAULT_URI__",
    "appinsights_key": "__APPINSIGHTS_KEY__",
    "azure_paas_podidentity_isEnabled": "__AZURE_ENABLE_MSI__",
    "AZURE_TENANT_ID": "__AZURE_TENANT_ID__",
    "AZURE_CLIENT_ID": "__AZURE_CLIENT_ID__",
    "AZURE_CLIENT_SECRET": "__AZURE_CLIENT_SECRET__",
    "aad_client_id": "__AAD_CLIENT_ID__"
}
if data_service_to_use:
    env_vars["data_service_to_use"] = data_service_to_use

operator_kwargs = {"labels": {"aadpodidbinding": "osdu-identity"}, "annotations": {"sidecar.istio.io/inject": "false"}}

with DAG(
    DAG_NAME,
    default_args=default_args,
    schedule_interval=None
) as dag:
    update_status_running = UpdateStatusOperator(
        task_id="update_status_running",
    )

    csv_parser = KubernetesPodOperator(
        namespace=NAMESPACE,
        task_id=CSV_PARSER,
        name=CSV_PARSER,
        env_vars=env_vars,
        arguments=[dumps(params)],
        is_delete_operator_pod=True,
        image=DOCKER_IMAGE,
        **operator_kwargs)

    update_status_finished = UpdateStatusOperator(
        task_id="update_status_finished",
        trigger_rule="all_done"
    )

update_status_running >> csv_parser >> update_status_finished # pylint: disable=pointless-statement