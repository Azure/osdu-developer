from datetime import timedelta
from json import dumps

import airflow
from airflow import DAG
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from osdu_airflow.backward_compatibility.default_args import update_default_args
from osdu_airflow.operators.update_status import UpdateStatusOperator

# default args for airflow
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': airflow.utils.dates.days_ago(0),
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

default_args = update_default_args(default_args)

# Get values from dag run configuration
record_id = "{{ dag_run.conf['execution_context']['id'] }}"
authorization = "{{ dag_run.conf['authToken'] }}"
dataPartitionId = "{{ dag_run.conf['execution_context']['dataPartitionId'] }}"
run_id = "{{ dag_run.conf['run_id'] }}"
data_service_to_use = "{{ dag_run.conf['execution_context'].get('data_service_to_use', 'file') }}"
steps = ["LOAD_FROM_CSV", "TYPE_COERCION", "ID", "ACL", "LEGAL", "KIND", "META", "TAGS", "UNIT", "CRS", "RELATIONSHIP", "STORE_TO_OSDU"]
user_id = "{{ dag_run.conf['execution_context'].get('userId') }}"

# Constants
DAG_NAME = "{| DAG_NAME |}"
DOCKER_IMAGE = "{| DOCKER_IMAGE |}"
NAMESPACE = "{| NAMESPACE |}"
CSV_PARSER = "csv-parser"

# Values to pass to csv parser
params = {
    "id": record_id,
    "authorization": authorization,
    "dataPartitionId": dataPartitionId,
    "steps": steps,
    "dataServiceName": "{{ dag_run.conf['execution_context'].get('data_service_to_use', 'file') }}",
    "userId":user_id
}

# Get environment variables
# TODO: put env vars here from application.properties
env_vars = {| ENV_VARS or {} |}
if data_service_to_use:
    env_vars["data_service_to_use"] = data_service_to_use

operator_kwargs = {| K8S_POD_OPERATOR_KWARGS or {} |}

with DAG(
    DAG_NAME,
    default_args=default_args,
    schedule_interval=None
) as dag:
    update_status_running = UpdateStatusOperator(
        task_id="update_status_running",
    )

    csv_parser = KubernetesPodOperator(
        namespace=NAMESPACE,
        task_id=CSV_PARSER,
        name=CSV_PARSER,
        env_vars=env_vars,
        arguments=[dumps(params)],
        is_delete_operator_pod=True,
        image=DOCKER_IMAGE,
        **operator_kwargs)

    update_status_finished = UpdateStatusOperator(
        task_id="update_status_finished",
        trigger_rule="all_done"
    )

update_status_running >> csv_parser >> update_status_finished # pylint: disable=pointless-statement
