# CSV Parser Airflow DAG

Airflow DAG provides the capability to ingest CSV files into the OSDU instance.

The `csv_ingestion_all_steps.py` file presenting a DAG with `csv_parser` step with all [CVS parser utility](../README.md) steps.

# DAG File Compilation
The DAG file contains a number of placeholders `{| |}`, specifying to put proper values there, e.g.

```python 
DAG_NAME = "{| DAG_NAME |}"
DOCKER_IMAGE = "{| DOCKER_IMAGE |}"
NAMESPACE = "{| NAMESPACE |}"
...
```

These values have to be populated before the DAG is deployed.
To bootstrap the DAG file cloud providers provide their specific `bootstrap` [scripts](../deployments).

# DAG Release and Distribution

## Google Cloud
Google Cloud DAG version is distributed as a generic package. During OSDU release the bootstrapped DAG file is published to the [Gitlab Generic Registy](https://community.opengroup.org/help/user/packages/generic_packages/index.md#publish-a-generic-package-by-using-cicd).

# DAG Deployment
## Dependencies
The [Airflow DAG](./csv_ingestion_all_steps.py) has dependencies which are listed in [requirements.txt](./requirements.txt) file.

## Google Cloud
For Google Cloud, the bootstrapped DAG only uses Airflow variables to populate these values at runtime.

Before deploying this DAG, make sure the following Airlfow variables are set:

| Name  | Default |Description |
| ------------- |------------- | ------------- |
| `core__service__storage__url` | - | OSDU Storage Service URL  |
| `core__service__schema__url`| - | OSDU Schema Service URL  |
| `core__service__search__url`| - | OSDU Search Service URL  |
| `core__service__partition__url`| - | OSDU Partition Service URL  |
| `core__service__unit__url`| - | OSDU Unit Service URL  |
| `core__service__file__url`| - | OSDU File Service URL |
| `core__service__dataset__url`| - | OSDU Dataset Service URL  |
| `core__service__workflow__url`| - | OSDU Workflow Service URL  |
| `gcp__data_partition_id`| - | Data partition ID  |
| `gcp__image__csv_parser`| - | CVS parser image |
| `gcp__csv_ingestion_request_memory`| 1Gi | Request Memory  |
| `gcp__csv_ingestion_request_cpu`| 200m | Request CPU  |
| `gcp__csv_ingestion_limit_memory`| 1Gi | Memory Limit  |
| `gcp__csv_ingestion_limit_cpu`| 1000m | CPU Limit  |

**Note**: Environment variables can be used as well. Pelase see [Airflow Documnetation](https://airflow.apache.org/docs/apache-airflow/stable/howto/variable.html#storing-variables-in-environment-variables)

# Testing
## End-to-End Testing
Deployed DAG functionality can be tested by [e2e testing collection](https://community.opengroup.org/osdu/platform/testing/-/tree/master/Postman%20Collection/31_CICD_Setup_CSVIngestion).

