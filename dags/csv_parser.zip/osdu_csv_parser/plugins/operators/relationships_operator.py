from airflow.models.baseoperator import BaseOperator
from airflow.utils.decorators import apply_defaults
from azure.storage.blob import ContainerClient
import requests
from json import dumps, loads
import logging

logging.basicConfig(level=logging.INFO)


class RelationshipsOperator(BaseOperator):

    @apply_defaults
    def __init__(self, source: str, destination: str, xcom_key: str, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.source = source
        self.destination = destination
        self.xcom_key = xcom_key
        self.run_id = None
        self.record_id = None
        self.storage_sas = None
        self.headers = None
        self.container = None
        self.storage_service_endpoint = None
        self.search_service_endpoint = None

    def execute(self, context):

        logging.info("Relationships Operator Started...")

        task_instance = context['task_instance']
        value = task_instance.xcom_pull(task_ids=self.xcom_key)

        self.run_id = value.get("runId")
        self.record_id = value.get("id")
        self.storage_sas = value.get("storageSas")
        self.headers = self.get_headers(value)
        self.container = ContainerClient.from_container_url(self.storage_sas)
        self.storage_service_endpoint = value.get("storage_service_endpoint")
        self.search_service_endpoint = value.get("search_service_endpoint")
        file_contents_details, records = self.get_records()
        related_natural_key = file_contents_details.get("relatedNaturalKey", [])

        for count, record in enumerate(records):
            data = record.get("data")

            # Get Relationships
            relationships = self.get_relationships(related_natural_key, data)

            # Add relationships to record's data block
            data["relationships"] = relationships

            # Upload
            self.upload(record, count + 1)

        logging.info("Relationships Operator finished...")

        return "Success"

    def get_records(self):

        file_dms_record = self.read_from_datalake(self.record_id)

        file_contents_details = file_dms_record.get("data", {}).get("ExtensionProperties", {}).get("FileContentsDetails", {})

        records = self.read_from_container()

        return file_contents_details, records

    def read_from_datalake(self, record_id):
        try:
            url = "{}/{}/{}".format(self.storage_service_endpoint, "records", record_id)
            response = requests.get(url, headers=self.headers)

            response_dict = loads(response.text)

            if response.ok and response.status_code in range(200, 205):
                logging.info("Storage operation success.")
                return response_dict
            else:
                logging.error("Storage operation failed with code {}, reason {}".format(response.status_code, response_dict))
                return {}
        except Exception as e:
            logging.error("Exception occur while getting record from datalake: {}".format(e))

    def read_from_container(self):

        records = []

        blob_list = self.container.list_blobs(name_starts_with="{}/{}/".format(self.run_id, self.source))

        for blob in blob_list:
            blob_client = self.container.get_blob_client(blob.name)
            download_stream = blob_client.download_blob()
            bytes_data = download_stream.readall()
            records.append(loads(bytes_data.decode("utf-8")))

        return records

    def upload(self, record, file_name):
        file_path = "{}/{}/{}".format(self.run_id, self.destination, file_name)
        self.container.upload_blob(name=file_path, data=dumps(record))

    @staticmethod
    def get_headers(arguments):
        return {
            "Content-Type": "application/json",
            "Authorization": arguments.get("authorization"),
            "Data-Partition-Id": arguments.get("dataPartitionId")
        }

    def get_relationships(self, related_natural_key, data):

        relationships = dict()
        for natural_key in related_natural_key:
            single_key = natural_key.get("singlekey", {})
            source_column = single_key.get("sourceColumn")
            target_kind = single_key.get("targetKind")
            target_attribute = single_key.get("targetAttribute")
            relationship_name = single_key.get("relationship-name")

            payload = {
                "kind": target_kind,
                "query": f"data.{target_attribute}:{data.get(source_column, None)}"
            }
            response = self.search(payload)
            if len(response.get("results", "")):
                logging.info("Forming relationship block.")
                relationships[relationship_name] = dict()
                try:
                    relationships[relationship_name]["ids"] = [rs["id"] for rs in response["results"]]
                except KeyError:
                    logging.debug("No id attribute found in given record {}".format(response["results"]))

        return relationships

    def search(self, payload):
        logging.info("Searching record for query: {}".format(payload))

        response = requests.post(self.search_service_endpoint, data=dumps(payload), headers=self.headers)

        if response.status_code not in range(200, 206):
            logging.error("response status while searching record: {}".format(response.status_code))

        return loads(response.text)
