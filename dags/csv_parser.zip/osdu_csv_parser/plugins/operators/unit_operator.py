from airflow.models.baseoperator import BaseOperator
from airflow.utils.decorators import apply_defaults
from azure.storage.blob import ContainerClient
import requests
import json
import copy
import logging

logging.basicConfig(level=logging.INFO)


class UnitOperator(BaseOperator):

    @apply_defaults
    def __init__(self, source: str, destination: str, xcom_key: str, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.source = source
        self.destination = destination
        self.xcom_key = xcom_key
        self.run_id = None
        self.record_id = None
        self.storage_sas = None
        self.headers = None
        self.container = None
        self.unit_conversion_endpoint = None
        self.storage_service_endpoint = None

    def execute(self, context):

        logging.info("Unit Operator Started...")

        task_instance = context['task_instance']
        value = task_instance.xcom_pull(task_ids=self.xcom_key)

        self.run_id = value.get("runId")
        self.record_id = value.get("id")
        self.storage_sas = value.get("storageSas")
        self.headers = self.get_headers(value)
        self.container = ContainerClient.from_container_url(self.storage_sas)
        self.unit_conversion_endpoint = value.get("unit_conversion_endpoint")
        self.storage_service_endpoint = value.get("storage_service_endpoint")

        metadata = []

        file_contents_details, records = self.get_records()

        for_meta_block = file_contents_details.get("FrameOfReference", [])
        unit_of_measure = file_contents_details.get("unitOfMeasure", "")

        if not unit_of_measure and not unit_of_measure.strip():
            unit_of_measure = 'Energistics_UoM'

        for count, record in enumerate(records):
            data = record.get("data")

            # Collect all available and not available meta block from file dms
            available_meta, not_available_meta = self.filter_dms_meta(for_meta_block)

            # Check if persistableReference is present for any unit in file dms.
            filter_not_available_meta = self.filter_present_persistable_reference(data, available_meta, not_available_meta)

            # Collect propertyNames and unit to call unit conversion service
            units = self.get_units(data, filter_not_available_meta)

            if units:
                # Get unitOfMeasure from file dms and pass it to unit conversion service.
                metadata = self.get_metadata(units, unit_of_measure)

            if metadata:
                available_meta.extend(metadata)

            # Extend meta data in record's meta block and push it to storage.
            try:
                record["meta"].extend(available_meta)
            except KeyError:
                record["meta"] = available_meta

            self.upload(record, count + 1)

            logging.info("Upload records with metadata finished.")

        logging.info("Unit Operator finished...")

        return "Success"

    def get_metadata(self, units, unit_of_measure):
        try:
            logging.info("Creating metadata..")
            meta_info = []
            visited_unit = {}

            for key in units.keys():
                meta = {}
                unit_args = {"temporary": {"unitKey": units[key]}}
                if units.get(key) not in visited_unit.keys():
                    try:
                        persistable_reference = self.unit_conversion(unit_args, unit_of_measure)
                        decoded_persistable_reference = persistable_reference["temporary"]["unit"]
                    except KeyError:
                        logging.info("{} unit is not convertable".format(unit_args))
                        decoded_persistable_reference = ""

                    meta["kind"] = "Unit"
                    meta["name"] = units[key]
                    meta["persistableReference"] = decoded_persistable_reference
                    meta["propertyNames"] = [key]
                    visited_unit[units[key]] = meta.get("persistableReference")
                    meta_info.append(meta)
                else:
                    for metadata in meta_info:
                        if metadata["name"] == units[key] and metadata["kind"] == "Unit":
                            metadata["propertyNames"].append(key)
            return meta_info
        except Exception as e:
            logging.error("failed to create metadata {}".format(e))

    def unit_conversion(self, unit_args, unit_of_measure):
        curve_unit_dict = {}
        for key in unit_args:
            if unit_args[key]['unitKey']:
                unit_key = unit_args[key]['unitKey'].replace('/', '%2F')
                try:
                    unit_args[key]["unit"] = curve_unit_dict[unit_key]
                except KeyError:
                    # special character handled for % symbol
                    if unit_key is '%':
                        unit_key = "{}{}".format(unit_key, 25)

                    url_for_unit = "{}/{}/{}".format(self.unit_conversion_endpoint, unit_of_measure, unit_key)

                    logging.info("Calling unit conversion service for unit: {}".format(unit_key))

                    self.convert_unit(url_for_unit, unit_args, key, unit_key, curve_unit_dict)

        return unit_args

    def convert_unit(self, url_for_unit, unit_args, key, unit_key, curve_unit_dict):
        try:
            resp = requests.get(url_for_unit, headers=self.headers)
            content = resp.text.replace('null', '""')
            content_json = json.loads(content)
            if "deprecationInfo" in content_json.keys():
                if content_json["deprecationInfo"] and content_json["deprecationInfo"]["state"] == "identical":
                    converted_unit = content_json["deprecationInfo"]["supersededByUnit"]
                else:
                    converted_unit = content_json["persistableReference"]
                unit_args[key]["unit"] = converted_unit
                curve_unit_dict[unit_key] = converted_unit
        except Exception as e:
            logging.error("{} unit is not convertible, Exception occur during unit conversion:{}".format(
                unit_args[key]["unitKey"], e))

    @staticmethod
    def get_units(data, not_available_meta):
        units = {}
        if not_available_meta:
            for na in copy.deepcopy(not_available_meta):
                property_names = na.get("propertyNames")
                for property_name in property_names:
                    # Filter if value present in record's data or not
                    if data.get(property_name, None):
                        units[property_name] = na.get("name").lower()
        return units

    @staticmethod
    def filter_dms_meta(for_meta_block):
        available_meta = []
        not_available_meta = []
        for item in for_meta_block:
            if item.get("kind", None) == "Unit":
                if item.get("persistableReference", None):
                    available_meta.append(item)
                else:
                    not_available_meta.append(item)
        return available_meta, not_available_meta

    @staticmethod
    def filter_present_persistable_reference(data, available_meta, not_available_meta):
        copy_not_available_meta = copy.deepcopy(not_available_meta)
        for na in not_available_meta:
            for a in available_meta:
                if na.get("name").lower() == a.get("name").lower():
                    # Filter if value present in record's data or not
                    property_names = na.get("propertyNames")
                    for property_name in property_names:
                        if data.get(property_name, None):
                            a.get("propertyNames").append(property_name)
                    copy_not_available_meta.remove(na)
                    break
        return copy_not_available_meta

    def get_records(self):

        file_dms_record = self.read_from_datalake(self.record_id)

        file_contents_details = file_dms_record.get("data", {}).get("ExtensionProperties", {}).get("FileContentsDetails", {})

        records = self.read_from_container()

        return file_contents_details, records

    def read_from_datalake(self, record_id):
        try:
            url = "{}/{}/{}".format(self.storage_service_endpoint, "records", record_id)
            response = requests.get(url, headers=self.headers)

            response_dict = json.loads(response.text)

            if response.ok and response.status_code in range(200, 205):
                logging.info("Storage operation success.")
                return response_dict
            else:
                logging.error("Storage operation failed with code {}, reason {}".format(response.status_code, response_dict))
                return {}
        except Exception as e:
            logging.error("Exception occur while getting record from datalake: {}".format(e))

    def read_from_container(self):

        records = []

        blob_list = self.container.list_blobs(name_starts_with="{}/{}/".format(self.run_id, self.source))

        for blob in blob_list:
            blob_client = self.container.get_blob_client(blob.name)
            download_stream = blob_client.download_blob()
            bytes_data = download_stream.readall()
            records.append(json.loads(bytes_data.decode("utf-8")))

        return records

    def upload(self, record, file_name):
        file_path = "{}/{}/{}".format(self.run_id, self.destination, file_name)
        self.container.upload_blob(name=file_path, data=json.dumps(record))

    @staticmethod
    def get_headers(arguments):
        return {
            "Content-Type": "application/json",
            "Authorization": arguments.get("authorization"),
            "Data-Partition-Id": arguments.get("dataPartitionId")
        }
