from datetime import timedelta
from json import dumps
import airflow
from airflow import DAG
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from osdu_airflow.backward_compatibility.default_args import update_default_args
from osdu_airflow.operators.update_status import UpdateStatusOperator
# default args for airflow
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': airflow.utils.dates.days_ago(0),
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
default_args = update_default_args(default_args)
# Get values from dag run configuration
record_id = "{{ dag_run.conf['execution_context']['id'] }}"
authorization = "{{ dag_run.conf['authToken'] }}"
dataPartitionId = "{{ dag_run.conf['execution_context']['dataPartitionId'] }}"
run_id = "{{ dag_run.conf['run_id'] }}"
data_service_to_use = "{{ dag_run.conf['execution_context'].get('data_service_to_use', 'file') }}"
steps = ["LOAD_FROM_CSV", "TYPE_COERCION", "ID", "ACL", "LEGAL", "KIND", "META", "TAGS", "UNIT", "CRS", "RELATIONSHIP", "STORE_TO_OSDU"]
user_id = "{{ dag_run.conf['execution_context'].get('userId') }}"
# Constants
DAG_NAME = "csv-parser"
DOCKER_IMAGE = "community.opengroup.org:5555/osdu/platform/data-flow/ingestion/csv-parser/csv-parser/csv-parser-v0-27-0-azure-1:60747714ac490be0defe8f3e821497b3cce03390"
NAMESPACE = "airflow"
CSV_PARSER = "csv-parser"
# Values to pass to csv parser
params = {
    "id": record_id,
    "authorization": authorization,
    "dataPartitionId": dataPartitionId,
    "steps": steps,
    "dataServiceName": "{{ dag_run.conf['execution_context'].get('data_service_to_use', 'file') }}",
    "userId":user_id
}
# Get environment variables
# TODO: put env vars here from application.properties
env_vars = {
  "storage_service_endpoint": "http://storage.osdu-core.svc.cluster.local/api/storage/v2",
  "schema_service_endpoint": "http://schema.osdu-core.svc.cluster.local/api/schema-service/v1",
  "search_service_endpoint": "http://search.osdu-core.svc.cluster.local/api/search/v2",
  "partition_service_endpoint": "http://partition.osdu-core.svc.cluster.local/api/partition/v1",
  "unit_service_endpoint": "http://unit.osdu-core.svc.cluster.local/api/unit/v2/unit/symbol",
  "file_service_endpoint": "http://file.osdu-core.svc.cluster.local/api/file/v2",
  "KEYVAULT_URI": "https://dummy-keyvault.vault.azure.net/",
  "appinsights_key": "dummy-app-insights-key",
  "azure_paas_podidentity_isEnabled": "false",
  "AZURE_TENANT_ID": "dummy-tenant-id",
  "AZURE_CLIENT_ID": "dummy-client-id",
  "AZURE_CLIENT_SECRET": "dummy-client-secret",
  "aad_client_id": "dummy-client-id"
}
if data_service_to_use:
    env_vars["data_service_to_use"] = data_service_to_use
operator_kwargs = {
  "labels": "{'aadpodidbinding': 'osdu-identity'}",
  "annotations": "{'sidecar.istio.io/inject': 'false'}"
}
with DAG(
    DAG_NAME,
    default_args=default_args,
    schedule_interval=None
) as dag:
    update_status_running = UpdateStatusOperator(
        task_id="update_status_running",
    )
    csv_parser = KubernetesPodOperator(
        namespace=NAMESPACE,
        task_id=CSV_PARSER,
        name=CSV_PARSER,
        env_vars=env_vars,
        arguments=[dumps(params)],
        is_delete_operator_pod=True,
        image=DOCKER_IMAGE,
        **operator_kwargs)
    update_status_finished = UpdateStatusOperator(
        task_id="update_status_finished",
        trigger_rule="all_done"
    )
update_status_running >> csv_parser >> update_status_finished # pylint: disable=pointless-statement