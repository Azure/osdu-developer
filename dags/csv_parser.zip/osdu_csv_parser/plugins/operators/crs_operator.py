from airflow.models.baseoperator import BaseOperator
from airflow.utils.decorators import apply_defaults
from azure.storage.blob import ContainerClient
import requests
import json
import copy
import logging

logging.basicConfig(level=logging.INFO)


class CrsOperator(BaseOperator):

    @apply_defaults
    def __init__(self, source: str, destination: str, xcom_key: str, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.source = source
        self.destination = destination
        self.xcom_key = xcom_key
        self.run_id = None
        self.record_id = None
        self.storage_sas = None
        self.headers = None
        self.container = None
        self.unit_conversion_endpoint = None
        self.storage_service_endpoint = None

    def execute(self, context):

        logging.info("CRS Operator Started...")

        task_instance = context['task_instance']
        value = task_instance.xcom_pull(task_ids=self.xcom_key)

        self.run_id = value.get("runId")
        self.record_id = value.get("id")
        self.storage_sas = value.get("storageSas")
        self.headers = self.get_headers(value)
        self.container = ContainerClient.from_container_url(self.storage_sas)
        self.unit_conversion_endpoint = value.get("unit_conversion_endpoint")
        self.storage_service_endpoint = value.get("storage_service_endpoint")

        file_contents_details, records = self.get_records()

        for_meta_block = file_contents_details.get("FrameOfReference", [])

        for count, record in enumerate(records):
            data = record.get("data")

            # Collect all available and not available meta block from file dms
            available_meta, not_available_meta = self.filter_dms_meta(for_meta_block)

            # Check if persistableReference is present for any CRS in file dms.
            filter_not_available_meta = self.filter_present_persistable_reference(data, available_meta, not_available_meta)

            logging.info("Persistable reference not available for CRS: " + json.dumps(filter_not_available_meta))

            # Extend meta data in record's meta block and push it to storage.
            try:
                record["meta"].extend(available_meta)
            except KeyError:
                record["meta"] = available_meta

            self.upload(record, count + 1)

            logging.info("Upload records with metadata finished.")

        logging.info("CRS Operator finished...")

        return "Success"

    @staticmethod
    def filter_dms_meta(for_meta_block):
        available_meta = []
        not_available_meta = []
        for item in for_meta_block:
            if item.get("kind", None) == "CRS":
                if item.get("persistableReference", None):
                    available_meta.append(item)
                else:
                    not_available_meta.append(item)
        return available_meta, not_available_meta

    @staticmethod
    def filter_present_persistable_reference(data, available_meta, not_available_meta):
        copy_not_available_meta = copy.deepcopy(not_available_meta)
        for na in not_available_meta:
            for a in available_meta:
                if na.get("name").lower() == a.get("name").lower():
                    # Filter if value present in record's data or not
                    property_names = na.get("propertyNames")
                    for property_name in property_names:
                        if data.get(property_name, None):
                            a.get("propertyNames").append(property_name)
                    copy_not_available_meta.remove(na)
                    break
        return copy_not_available_meta

    def get_records(self):

        file_dms_record = self.read_from_datalake(self.record_id)

        file_contents_details = file_dms_record.get("data", {}).get("ExtensionProperties", {}).get("FileContentsDetails", {})

        records = self.read_from_container()

        return file_contents_details, records

    def read_from_datalake(self, record_id):
        try:
            url = "{}/{}/{}".format(self.storage_service_endpoint, "records", record_id)
            response = requests.get(url, headers=self.headers)

            response_dict = json.loads(response.text)

            if response.ok and response.status_code in range(200, 205):
                logging.info("Storage operation success.")
                return response_dict
            else:
                logging.error("Storage operation failed with code {}, reason {}".format(response.status_code, response_dict))
                return {}
        except Exception as e:
            logging.error("Exception occur while getting record from datalake: {}".format(e))

    def read_from_container(self):

        records = []

        blob_list = self.container.list_blobs(name_starts_with="{}/{}/".format(self.run_id, self.source))

        for blob in blob_list:
            blob_client = self.container.get_blob_client(blob.name)
            download_stream = blob_client.download_blob()
            bytes_data = download_stream.readall()
            records.append(json.loads(bytes_data.decode("utf-8")))

        return records

    def upload(self, record, file_name):
        file_path = "{}/{}/{}".format(self.run_id, self.destination, file_name)
        self.container.upload_blob(name=file_path, data=json.dumps(record))

    @staticmethod
    def get_headers(arguments):
        return {
            "Content-Type": "application/json",
            "Authorization": arguments.get("authorization"),
            "Data-Partition-Id": arguments.get("dataPartitionId")
        }
